<?php
define('SQL_HOST', 'localhost');
define('SQL_USER', 'root');
define('SQL_PASS', 'campagnA96mamp');
define('SQL_DB', 'db_rush01');  
?>