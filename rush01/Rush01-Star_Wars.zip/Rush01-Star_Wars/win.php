<h1>GAME OVER</h1>
<?php

session_start();
$_SESSION['gz'] = "";

?>
<a href="./game.php">Play again</a>